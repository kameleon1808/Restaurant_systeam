<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hzn7mWXHSrh2BGUj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/upload-file' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.upload-file',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.js' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H1V36bAh1oOfV59B',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.js.map' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yCJxgXOlGv4xqLgB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IHeGETbByogDtvjv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::w4hd3WTk6zewnGpR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/role' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'loginOption',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rKDXN5yGPK3g01aw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::umX2sfKziFLCoWcF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/confirm' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z3PAUX6JvxDQoTs1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/shop' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.shop.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/cart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.cart.show',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.order',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/locate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.locate',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.cancel',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/remove' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.remove',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.update-qty',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/updateInformation' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.updateInformation',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/update-pwd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/shop' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.shop.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/cart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.cart.show',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.order',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/locate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.locate',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.cancel',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/remove' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.remove',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.update-qty',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/updateInformation' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.updateInformation',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/update-pwd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/boss/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'boss.showOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/boss/accept-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'boss.acceptOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/boss/send-location' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'boss.sendLocation',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/boss/finish-delivery' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'boss.finishDelivery',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/boss/location' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'boss.location',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/boss/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'boss.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.allStaff',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/deliverer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.showOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/state' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.statePage',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/waiter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.showOrders',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/porucivana-jela' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.popularArticles',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/prihodi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.amounts',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/mesecni-prihodi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.months',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/godisnji-prihodi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.years',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/korisnici-prihodi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.users',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/addWaiter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.addWaiter',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/addDeliverer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.addDeliverer',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/addState' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.addState',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/deleteStaff' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.deleteStaff',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rest-boss/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rest-boss.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/waiter/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'waiter.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/waiter/porudzbine' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'waiter.showOrders',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/waiter/createOrder' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'waiter.createOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/waiter/accept' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'waiter.accept',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/waiter/refuse' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'waiter.refuse',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/waiter/map' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'waiter.',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/waiter/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'waiter.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/state/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'state.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/state/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'state.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/state/porucivana-jela' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'state.popularArticles',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/state/prihodi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'state.amounts',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/state/mesecni-prihodi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'state.months',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/state/godisnji-prihodi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'state.years',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/state/korisnici-prihodi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'state.users',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/state/porudzbine' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'state.orders',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/l(?|ivewire/(?|message/([^/]++)(*:39)|preview\\-file/([^/]++)(*:68))|egal/(?|shop/([^/]++)(*:97)|edit\\-cart/([^/]++)(*:123)))|/address/([^/]++)(*:150)|/password/reset/([^/]++)(*:182)|/user/(?|shop/([^/]++)(*:212)|edit\\-cart/([^/]++)(*:239)))/?$}sDu',
    ),
    3 => 
    array (
      39 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.message',
          ),
          1 => 
          array (
            0 => 'name',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      68 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.preview-file',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      97 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.shop.show',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      123 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      150 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'redirectToAddress',
          ),
          1 => 
          array (
            0 => 'address',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      182 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      212 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.shop.show',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      239 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::hzn7mWXHSrh2BGUj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::hzn7mWXHSrh2BGUj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.message' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/message/{name}',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\HttpConnectionHandler@__invoke',
        'controller' => 'Livewire\\Controllers\\HttpConnectionHandler',
        'as' => 'livewire.message',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.upload-file' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/upload-file',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\FileUploadHandler@handle',
        'controller' => 'Livewire\\Controllers\\FileUploadHandler@handle',
        'as' => 'livewire.upload-file',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.preview-file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/preview-file/{filename}',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\FilePreviewHandler@handle',
        'controller' => 'Livewire\\Controllers\\FilePreviewHandler@handle',
        'as' => 'livewire.preview-file',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H1V36bAh1oOfV59B' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.js',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@source',
        'controller' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@source',
        'as' => 'generated::H1V36bAh1oOfV59B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yCJxgXOlGv4xqLgB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.js.map',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@maps',
        'controller' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@maps',
        'as' => 'generated::yCJxgXOlGv4xqLgB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IHeGETbByogDtvjv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:297:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:79:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000005cd0000000000000000";}";s:4:"hash";s:44:"2Moj2WVS/iFp530LyCIvQKxiD1OB+zPg2FHsxjv0wbk=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::IHeGETbByogDtvjv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::w4hd3WTk6zewnGpR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeGuestController@index',
        'controller' => 'App\\Http\\Controllers\\HomeGuestController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::w4hd3WTk6zewnGpR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'redirectToAddress' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'address/{address}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeGuestController@redirectToAddress',
        'controller' => 'App\\Http\\Controllers\\HomeGuestController@redirectToAddress',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'redirectToAddress',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'loginOption' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'role',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeGuestController@loginOption',
        'controller' => 'App\\Http\\Controllers\\HomeGuestController@loginOption',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'loginOption',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rKDXN5yGPK3g01aw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rKDXN5yGPK3g01aw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::umX2sfKziFLCoWcF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::umX2sfKziFLCoWcF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z3PAUX6JvxDQoTs1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::z3PAUX6JvxDQoTs1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\HomeController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@index',
        'as' => 'user.index',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.shop.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/shop',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\ShopController@index',
        'controller' => 'App\\Http\\Controllers\\User\\ShopController@index',
        'as' => 'user.shop.index',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.shop.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/shop/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\ShopController@show',
        'controller' => 'App\\Http\\Controllers\\User\\ShopController@show',
        'as' => 'user.shop.show',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.cart.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/cart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\CartController@show',
        'controller' => 'App\\Http\\Controllers\\User\\CartController@show',
        'as' => 'user.cart.show',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.order' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\OrderController@show',
        'controller' => 'App\\Http\\Controllers\\User\\OrderController@show',
        'as' => 'user.order',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.locate' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/locate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\OrderController@locate',
        'controller' => 'App\\Http\\Controllers\\User\\OrderController@locate',
        'as' => 'user.locate',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.cancel' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\OrderController@cancel',
        'controller' => 'App\\Http\\Controllers\\User\\OrderController@cancel',
        'as' => 'user.cancel',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\OrderController@create',
        'controller' => 'App\\Http\\Controllers\\User\\OrderController@create',
        'as' => 'user.create',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\CartController@store',
        'controller' => 'App\\Http\\Controllers\\User\\CartController@store',
        'as' => 'user.store',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.remove' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/remove',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\CartController@remove',
        'controller' => 'App\\Http\\Controllers\\User\\CartController@remove',
        'as' => 'user.remove',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@logout',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@logout',
        'as' => 'user.logout',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/edit-cart/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\CartController@edit',
        'controller' => 'App\\Http\\Controllers\\User\\CartController@edit',
        'as' => 'user.edit',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.update-qty' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\CartController@update',
        'controller' => 'App\\Http\\Controllers\\User\\CartController@update',
        'as' => 'user.update-qty',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@profile',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@profile',
        'as' => 'user.profile',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.updateInformation' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/updateInformation',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@updateInformation',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@updateInformation',
        'as' => 'user.updateInformation',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/update-pwd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@update',
        'as' => 'user.update',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isUser',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@delete',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@delete',
        'as' => 'user.delete',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\LegalController@index',
        'controller' => 'App\\Http\\Controllers\\Legal\\LegalController@index',
        'as' => 'legal.index',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.shop.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/shop',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\ShopController@index',
        'controller' => 'App\\Http\\Controllers\\Legal\\ShopController@index',
        'as' => 'legal.shop.index',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.shop.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/shop/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\ShopController@show',
        'controller' => 'App\\Http\\Controllers\\Legal\\ShopController@show',
        'as' => 'legal.shop.show',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.cart.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/cart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\CartController@show',
        'controller' => 'App\\Http\\Controllers\\Legal\\CartController@show',
        'as' => 'legal.cart.show',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.order' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\OrderController@show',
        'controller' => 'App\\Http\\Controllers\\Legal\\OrderController@show',
        'as' => 'legal.order',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.locate' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'legal/locate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\OrderController@locate',
        'controller' => 'App\\Http\\Controllers\\Legal\\OrderController@locate',
        'as' => 'legal.locate',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.cancel' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'legal/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\OrderController@cancel',
        'controller' => 'App\\Http\\Controllers\\Legal\\OrderController@cancel',
        'as' => 'legal.cancel',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'legal/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\OrderController@create',
        'controller' => 'App\\Http\\Controllers\\Legal\\OrderController@create',
        'as' => 'legal.create',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'legal/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\CartController@store',
        'controller' => 'App\\Http\\Controllers\\Legal\\CartController@store',
        'as' => 'legal.store',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.remove' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'legal/remove',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\CartController@remove',
        'controller' => 'App\\Http\\Controllers\\Legal\\CartController@remove',
        'as' => 'legal.remove',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'legal/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\LegalController@logout',
        'controller' => 'App\\Http\\Controllers\\Legal\\LegalController@logout',
        'as' => 'legal.logout',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/edit-cart/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\CartController@edit',
        'controller' => 'App\\Http\\Controllers\\Legal\\CartController@edit',
        'as' => 'legal.edit',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.update-qty' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'legal/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\CartController@update',
        'controller' => 'App\\Http\\Controllers\\Legal\\CartController@update',
        'as' => 'legal.update-qty',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\LegalController@profile',
        'controller' => 'App\\Http\\Controllers\\Legal\\LegalController@profile',
        'as' => 'legal.profile',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.updateInformation' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'legal/updateInformation',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\LegalController@updateInformation',
        'controller' => 'App\\Http\\Controllers\\Legal\\LegalController@updateInformation',
        'as' => 'legal.updateInformation',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'legal/update-pwd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\LegalController@update',
        'controller' => 'App\\Http\\Controllers\\Legal\\LegalController@update',
        'as' => 'legal.update',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'legal/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isLegal',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Legal\\LegalController@delete',
        'controller' => 'App\\Http\\Controllers\\Legal\\LegalController@delete',
        'as' => 'legal.delete',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'boss.showOrder' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'boss/home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Deliverer\\DelivererController@showOrder',
        'controller' => 'App\\Http\\Controllers\\Deliverer\\DelivererController@showOrder',
        'as' => 'boss.showOrder',
        'namespace' => NULL,
        'prefix' => '/boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'boss.acceptOrder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'boss/accept-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Deliverer\\DelivererController@acceptOrder',
        'controller' => 'App\\Http\\Controllers\\Deliverer\\DelivererController@acceptOrder',
        'as' => 'boss.acceptOrder',
        'namespace' => NULL,
        'prefix' => '/boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'boss.sendLocation' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'boss/send-location',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Deliverer\\DelivererController@sendLocation',
        'controller' => 'App\\Http\\Controllers\\Deliverer\\DelivererController@sendLocation',
        'as' => 'boss.sendLocation',
        'namespace' => NULL,
        'prefix' => '/boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'boss.finishDelivery' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'boss/finish-delivery',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Deliverer\\DelivererController@finishDelivery',
        'controller' => 'App\\Http\\Controllers\\Deliverer\\DelivererController@finishDelivery',
        'as' => 'boss.finishDelivery',
        'namespace' => NULL,
        'prefix' => '/boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'boss.location' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'boss/location',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Deliverer\\DelivererController@location',
        'controller' => 'App\\Http\\Controllers\\Deliverer\\DelivererController@location',
        'as' => 'boss.location',
        'namespace' => NULL,
        'prefix' => '/boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'boss.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'boss/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Deliverer\\DelivererController@logout',
        'controller' => 'App\\Http\\Controllers\\Deliverer\\DelivererController@logout',
        'as' => 'boss.logout',
        'namespace' => NULL,
        'prefix' => '/boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.allStaff' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rest-boss/home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@allStaff',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@allStaff',
        'as' => 'rest-boss.allStaff',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.showOrder' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rest-boss/deliverer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@showOrder',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@showOrder',
        'as' => 'rest-boss.showOrder',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.statePage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rest-boss/state',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@statePage',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@statePage',
        'as' => 'rest-boss.statePage',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.showOrders' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rest-boss/waiter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@showOrders',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@showOrders',
        'as' => 'rest-boss.showOrders',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.popularArticles' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rest-boss/porucivana-jela',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@popularArticles',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@popularArticles',
        'as' => 'rest-boss.popularArticles',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.amounts' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rest-boss/prihodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@amounts',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@amounts',
        'as' => 'rest-boss.amounts',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.months' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rest-boss/mesecni-prihodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@months',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@months',
        'as' => 'rest-boss.months',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.years' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rest-boss/godisnji-prihodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@years',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@years',
        'as' => 'rest-boss.years',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.users' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rest-boss/korisnici-prihodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@users',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@users',
        'as' => 'rest-boss.users',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.addWaiter' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'rest-boss/addWaiter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@addWaiter',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@addWaiter',
        'as' => 'rest-boss.addWaiter',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.addDeliverer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'rest-boss/addDeliverer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@addDeliverer',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@addDeliverer',
        'as' => 'rest-boss.addDeliverer',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.addState' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'rest-boss/addState',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@addState',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@addState',
        'as' => 'rest-boss.addState',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.deleteStaff' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'rest-boss/deleteStaff',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@deleteStaff',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@deleteStaff',
        'as' => 'rest-boss.deleteStaff',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'rest-boss/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@update',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@update',
        'as' => 'rest-boss.update',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rest-boss.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'rest-boss/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isRestBoss',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@logout',
        'controller' => 'App\\Http\\Controllers\\RestBoss\\RestBossController@logout',
        'as' => 'rest-boss.logout',
        'namespace' => NULL,
        'prefix' => '/rest-boss',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'waiter.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'waiter/home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isWaiter',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Waiter\\WaiterController@index',
        'controller' => 'App\\Http\\Controllers\\Waiter\\WaiterController@index',
        'as' => 'waiter.index',
        'namespace' => NULL,
        'prefix' => '/waiter',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'waiter.showOrders' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'waiter/porudzbine',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isWaiter',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Waiter\\OrderController@showOrders',
        'controller' => 'App\\Http\\Controllers\\Waiter\\OrderController@showOrders',
        'as' => 'waiter.showOrders',
        'namespace' => NULL,
        'prefix' => '/waiter',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'waiter.createOrder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'waiter/createOrder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isWaiter',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Waiter\\OrderController@createOrder',
        'controller' => 'App\\Http\\Controllers\\Waiter\\OrderController@createOrder',
        'as' => 'waiter.createOrder',
        'namespace' => NULL,
        'prefix' => '/waiter',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'waiter.accept' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'waiter/accept',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isWaiter',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Waiter\\OrderController@accept',
        'controller' => 'App\\Http\\Controllers\\Waiter\\OrderController@accept',
        'as' => 'waiter.accept',
        'namespace' => NULL,
        'prefix' => '/waiter',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'waiter.refuse' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'waiter/refuse',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isWaiter',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Waiter\\OrderController@refuse',
        'controller' => 'App\\Http\\Controllers\\Waiter\\OrderController@refuse',
        'as' => 'waiter.refuse',
        'namespace' => NULL,
        'prefix' => '/waiter',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'waiter.' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'waiter/map',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isWaiter',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Waiter\\OrderController@indexx',
        'controller' => 'App\\Http\\Controllers\\Waiter\\OrderController@indexx',
        'as' => 'waiter.',
        'namespace' => NULL,
        'prefix' => '/waiter',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'waiter.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'waiter/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isWaiter',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Waiter\\WaiterController@logout',
        'controller' => 'App\\Http\\Controllers\\Waiter\\WaiterController@logout',
        'as' => 'waiter.logout',
        'namespace' => NULL,
        'prefix' => '/waiter',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'state.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'state/home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isState',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\State\\StateController@index',
        'controller' => 'App\\Http\\Controllers\\State\\StateController@index',
        'as' => 'state.index',
        'namespace' => NULL,
        'prefix' => '/state',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'state.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'state/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isState',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\State\\StateController@logout',
        'controller' => 'App\\Http\\Controllers\\State\\StateController@logout',
        'as' => 'state.logout',
        'namespace' => NULL,
        'prefix' => '/state',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'state.popularArticles' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'state/porucivana-jela',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isState',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\State\\OrdersController@popularArticles',
        'controller' => 'App\\Http\\Controllers\\State\\OrdersController@popularArticles',
        'as' => 'state.popularArticles',
        'namespace' => NULL,
        'prefix' => '/state',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'state.amounts' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'state/prihodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isState',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\State\\OrdersController@amounts',
        'controller' => 'App\\Http\\Controllers\\State\\OrdersController@amounts',
        'as' => 'state.amounts',
        'namespace' => NULL,
        'prefix' => '/state',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'state.months' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'state/mesecni-prihodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isState',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\State\\OrdersController@months',
        'controller' => 'App\\Http\\Controllers\\State\\OrdersController@months',
        'as' => 'state.months',
        'namespace' => NULL,
        'prefix' => '/state',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'state.years' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'state/godisnji-prihodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isState',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\State\\OrdersController@years',
        'controller' => 'App\\Http\\Controllers\\State\\OrdersController@years',
        'as' => 'state.years',
        'namespace' => NULL,
        'prefix' => '/state',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'state.users' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'state/korisnici-prihodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isState',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\State\\OrdersController@users',
        'controller' => 'App\\Http\\Controllers\\State\\OrdersController@users',
        'as' => 'state.users',
        'namespace' => NULL,
        'prefix' => '/state',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'state.orders' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'state/porudzbine',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isState',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Waiter\\OrderController@showOrders',
        'controller' => 'App\\Http\\Controllers\\Waiter\\OrderController@showOrders',
        'as' => 'state.orders',
        'namespace' => NULL,
        'prefix' => '/state',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
