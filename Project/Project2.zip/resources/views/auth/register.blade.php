@extends('layouts.app')

@section('content')
    @if (Auth::check())
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">{{ auth()->guard()->user()->name }}</div>

                        <div class="card-body">
                            <div class="row mb-6">
                                <label for="email"
                                    class="col-md-4 col-form-label text-md-end">{{ __('Vec ste prijavljeni, molimo vas odjavite se!') }}</label>

                                <a class="dropdown-item" href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    {{ __('Odjavite se') }}
                                </a>


                                @if (auth()->guard()->user()->role == 1)
                                    <a href="{{ 'boss/home' }}" type="button"
                                        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">Pocetna
                                        strana</a><br>
                                @elseif (auth()->guard()->user()->role == 2)
                                    <a href="{{ 'user/home' }}" type="button"
                                        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">Pocetna
                                        strana</a><br>
                                @elseif (auth()->guard()->user()->role == 3)
                                    <a href="{{ 'waiter/home' }}" type="button"
                                        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">Pocetna
                                        strana</a><br>
                                @elseif (auth()->guard()->user()->role == 4)
                                    <a href="{{ 'state/home' }}" type="button"
                                        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">Pocetna
                                        stranaa</a><br>
                                @elseif (auth()->guard()->user()->role == 5)
                                    <a href="{{ 'legal/home' }}" type="button"
                                        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">Pocetna
                                        strana</a><br>
                                @elseif (auth()->guard()->user()->role == 6)
                                    <a href="{{ 'rest-boss/home' }}" type="button"
                                        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">Pocetna
                                        strana</a><br>
                                @endif
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    @else
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">{{ __('Register') }}</div>

                        <div class="card-body">
                            <form method="POST" action="{{ route('register') }}">
                                @csrf

                                <div class="row mb-3">
                                    <label for="name"
                                        class="col-md-4 col-form-label text-md-end">{{ __('Name') }}</label>

                                    <div class="col-md-6">
                                        <input id="name" type="text"
                                            class="form-control @error('name') is-invalid @enderror" name="name"
                                            value="{{ old('name') }}" required autocomplete="name" autofocus>

                                        @error('name')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="email"
                                        class="col-md-4 col-form-label text-md-end">{{ __('Email Address') }}</label>

                                    <div class="col-md-6">
                                        <input id="email" type="email"
                                            class="form-control @error('email') is-invalid @enderror" name="email"
                                            value="{{ old('email') }}" required autocomplete="email">

                                        @error('email')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="address"
                                        class="col-md-4 col-form-label text-md-end">{{ __('Address') }}</label>

                                    <div class="col-md-6">
                                        <input id="address" type="text"
                                            class="form-control @error('address') is-invalid @enderror" name="address"
                                            value="{{ old('address') }}" required autofocus>

                                        @error('address')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                {{-- <div class="row mb-3">
                                    <label for="company_name"
                                        class="col-md-4 col-form-label text-md-end">{{ __('Company name') }}</label>

                                    <div class="col-md-6">
                                        <input id="company_name" type="text"
                                            class="form-control @error('company_name') is-invalid @enderror"
                                            name="company_name" value="{{ old('company_name') }}" autofocus>

                                        @error('company_name')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div> --}}

                                <div class="row mb-3">
                                    <label for="phone"
                                        class="col-md-4 col-form-label text-md-end">{{ __('Phone') }}</label>

                                    <div class="col-md-6">
                                        <input id="phone" type="text"
                                            class="form-control @error('phone') is-invalid @enderror" name="phone"
                                            value="{{ old('phone') }}" required autofocus>

                                        @error('phone')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="username"
                                        class="col-md-4 col-form-label text-md-end">{{ __('Username') }}</label>

                                    <div class="col-md-6">
                                        <input id="username" type="text"
                                            class="form-control @error('username') is-invalid @enderror" name="username"
                                            value="{{ old('username') }}" required autofocus>

                                        @error('username')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="role"
                                        class="col-md-4 col-form-label text-md-end">{{ __('Role') }}</label>

                                    <div class="col-md-6">
                                        <input type="radio" class="role" name="role" type="radio"
                                            value="5" /> Legal Person
                                        <input type="radio" class="role" name="role" type="radio"
                                            value="2" checked /> Natural Person

                                        <table class="table">
                                            <tr class="colorCars">
                                                <td>
                                                    <input type="text" name="company_name" value=""
                                                        placeholder="Company name" />
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="password"
                                        class="col-md-4 col-form-label text-md-end">{{ __('Password') }}</label>

                                    <div class="col-md-6">
                                        <input id="password" type="password"
                                            class="form-control @error('password') is-invalid @enderror" name="password"
                                            required autocomplete="new-password">

                                        @error('password')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="password-confirm"
                                        class="col-md-4 col-form-label text-md-end">{{ __('Confirm Password') }}</label>

                                    <div class="col-md-6">
                                        <input id="password-confirm" type="password" class="form-control"
                                            name="password_confirmation" required autocomplete="new-password">
                                    </div>
                                </div>

                                <div class="row mb-0">
                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary">
                                            {{ __('Register') }}
                                        </button>
                                    </div>
                                </div>
                                <script src="http://code.jquery.com/jquery.js"></script>

                                <!-- Latest compiled and minified JavaScript -->
                                <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
                                <script>
                                    $(function() {
                                        $('.colorCars input').prop({
                                            readonly: true
                                        });
                                        $('.role').click(function() {
                                            if ($(this).val() == '5') {
                                                $('.colorCars input').prop({
                                                    readonly: false,
                                                    disabled: false
                                                });
                                            } else {
                                                $(' .colorCars input').prop({
                                                    readonly: false,
                                                    disabled: true,
                                                    value: null
                                                });
                                            }
                                        });
                                    });
                                </script>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif
@endsection
