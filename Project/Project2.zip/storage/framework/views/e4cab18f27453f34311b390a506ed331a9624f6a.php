

<?php $__env->startSection('home-w'); ?>
    <h1>Konobar home strana</h1>

    <h2><?php echo e(auth()->guard()->user()->name); ?></h2>

    <form action="<?php echo e(route('waiter.logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
            Logout
        </button>
    </form>

    <a type="button" href="<?php echo e(url('waiter/porudzbine')); ?>"
        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
        Porudzbine
    </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\resources\views/dashboard/waiter/home.blade.php ENDPATH**/ ?>