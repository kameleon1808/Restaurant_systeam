

<?php $__env->startSection('home-s'); ?>
    <h1>Stanje home strana</h1>

    <h2><?php echo e(auth()->guard()->user()->name); ?></h2>

    <form action="<?php echo e(route('state.logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
            Logout
        </button>
    </form>

    <a type="button" href="<?php echo e(url('state/porucivana-jela')); ?>"
        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
        Najcesce porucivana jela
    </a>

    <a type="button" href="<?php echo e(url('state/prihodi')); ?>"
        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
        Prihodi
    </a>

    <a type="button" href="<?php echo e(url('state/mesecni-prihodi')); ?>"
        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
        Prihodi po mesecima
    </a>

    <a type="button" href="<?php echo e(url('state/godisnji-prihodi')); ?>"
        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
        Prihodi po godinama
    </a>
    <a type="button" href="<?php echo e(url('state/korisnici-prihodi')); ?>"
        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
        Prihodi po korisnicima
    </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\resources\views/dashboard/state/home.blade.php ENDPATH**/ ?>