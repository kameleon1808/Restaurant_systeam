

<?php $__env->startSection('home-b'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('delivery', [])->html();
} elseif ($_instance->childHasBeenRendered('CQUjyBv')) {
    $componentId = $_instance->getRenderedChildComponentId('CQUjyBv');
    $componentTag = $_instance->getRenderedChildComponentTagName('CQUjyBv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CQUjyBv');
} else {
    $response = \Livewire\Livewire::mount('delivery', []);
    $html = $response->html();
    $_instance->logRenderedChild('CQUjyBv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\Project\resources\views/dashboard/boss/home.blade.php ENDPATH**/ ?>