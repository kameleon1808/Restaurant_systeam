

<?php $__env->startSection('article'); ?>
    <!-- CONTENT =============================-->
    <section class="item content">
        <div class="container toparea">
            <div class="underlined-title">
                <div class="editContent">
                    <h1 class="text-center latestitems"><?php echo e($a->name); ?></h1>
                </div>
                <div class="wow-hr type_short">
                    <span class="wow-hr-h">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </span>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8">
                    <div class="productbox">
                        
                        <img src="<?php echo e(asset($a->img)); ?>" alt="">
                        <div class="clearfix">
                        </div>
                        <br />
                        <div class="product-details text-left">
                            <p>
                                <?php echo e($a->details); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <form action="<?php echo e(route('user.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="article_id" value="<?php echo e($a->id); ?>">
                        <input type="hidden" name="price" value="<?php echo e($a->price); ?>">

                        <button type="submit" class="btn btn-buynow"><?php echo e($a->price); ?> RSD</button>

                        <b>Product quantity</b>
                        <br>
                        <input type="text" name="prod_qty" value="1">
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\Project\resources\views/dashboard/user/article.blade.php ENDPATH**/ ?>