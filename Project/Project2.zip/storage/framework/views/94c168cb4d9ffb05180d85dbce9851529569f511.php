

<?php $__env->startSection('waiter-h'); ?>
    <h1>Waiter home page</h1>

    <h2><?php echo e(auth()->guard()->user()->name); ?></h2>
    <br><br>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('orders', [])->html();
} elseif ($_instance->childHasBeenRendered('CpxCSsl')) {
    $componentId = $_instance->getRenderedChildComponentId('CpxCSsl');
    $componentTag = $_instance->getRenderedChildComponentTagName('CpxCSsl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CpxCSsl');
} else {
    $response = \Livewire\Livewire::mount('orders', []);
    $html = $response->html();
    $_instance->logRenderedChild('CpxCSsl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\resources\views/dashboard/rest-boss/waiter.blade.php ENDPATH**/ ?>