

<?php $__env->startSection('shop'); ?>
    <!-- CONTENT =============================-->
    <section class="item content">
        <div class="container toparea">
            <div class="underlined-title">
                <div class="editContent">
                    <h1 class="text-center latestitems">OUR PRODUCTS</h1>
                </div>
                <div class="wow-hr type_short">
                    <span class="wow-hr-h">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </span>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $art; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="productbox">
                            <div class="fadeshop">
                                <div class="captionshop text-center" style="display: none;">
                                    <h3><?php echo e($a->name); ?></h3>
                                    <p>
                                        <?php echo e($a->details); ?>

                                    </p>
                                    <p>
                                        <a href="#" class="learn-more detailslearn"><i
                                                class="fa fa-shopping-cart"></i>
                                            Purchase</a>
                                        <a href="#" class="learn-more detailslearn"><i class="fa fa-link"></i>
                                            Details</a>
                                    </p>
                                </div>
                                <span class="maxproduct">
                                    
                                    <img src="<?php echo e(asset($a->img)); ?>" alt="">
                                </span>
                            </div>
                            <div class="product-details">
                                <a href="shop/<?php echo e($a->slug); ?>">
                                    <h1><?php echo e($a->name); ?></h1>
                                </a>
                                <span class="price">
                                    <span class="edd_price"><?php echo e($a->price); ?> RSD</span>
                                </span>
                            </div>
                        </div>
                    </div>
                    <!-- /.productbox -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\Project\resources\views/dashboard/user/shop.blade.php ENDPATH**/ ?>