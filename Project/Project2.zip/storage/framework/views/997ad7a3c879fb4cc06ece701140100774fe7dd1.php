<div wire:poll>
    
    Current time: <?php echo e(now()); ?>


    <h1>Deliverer home strana</h1>

    <h2><?php echo e(auth()->guard()->user()->name); ?></h2>

    <form action="<?php echo e(route('boss.logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
            Logout
        </button>
    </form>

    <table class="table">
        <thead>
            <th>Datum kreiranja</th>
            <th>Narucilac</th>
            <th>Adresa za isporuku</th>
            <th>location</th>
            <th>Action</th>
            <th>Dostavljeno</th>
            <th>Otkazano</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($d->created_at); ?></td> 
                    <td><?php echo e($d->order->name); ?></td>
                    <td><?php echo e($d->order->shipping_address); ?> - <?php echo e($d->city); ?></td>
                    <td>
                        <a
                            href="https://yandex.ru/maps/?whatshere[point]=<?php echo e($d->location); ?>&whatshere[zoom]=17"><?php echo e($d->location); ?></a>
                    </td>
                    <td>
                        <?php if($d->boss_id == null): ?>
                            <?php if($d->canceled == 0): ?>
                                <form action="<?php echo e(route('boss.acceptOrder')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="ord_id" value="<?php echo e($d->id); ?>">
                                    <button type="submit" class="btn btn-outline-success"
                                        data-mdb-ripple-color="dark">Prihvati</button>
                                </form>
                            <?php else: ?>
                                <p>//</p>
                            <?php endif; ?>
                        <?php elseif($d->boss_id != null): ?>
                            <?php if($d->request == 1): ?>
                                <form action="<?php echo e(route('boss.location')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="ord_id" value="<?php echo e($d->id); ?>">
                                    <button type="submit" class="btn btn-outline-primary"
                                        data-mdb-ripple-color="dark">Posalji lokaciju</button>
                                </form>
                            <?php else: ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <td> 
                        <?php if($d->delivered != 1): ?>
                            <?php if($d->canceled == 0): ?>
                                <form action="<?php echo e(route('boss.finishDelivery')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="ord_id" value="<?php echo e($d->id); ?>">
                                    <button type="submit" class="btn btn-outline-dark"
                                        data-mdb-ripple-color="dark">Zavrsi isporuku</button>
                                </form>
                            <?php else: ?>
                                <p></p>
                            <?php endif; ?>
                        <?php elseif($d->delivered != 0): ?>
                            <button>Isporuceno</button>
                        <?php endif; ?>
                    </td>
                    <td> 
                        <?php if($d->canceled == 1): ?>
                            <button type="button" class="btn btn-outline-danger"
                                data-mdb-ripple-color="dark">Otkazana</button>
                        <?php else: ?>
                            <p></p>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>

</div>
<?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\Project\resources\views/livewire/delivery.blade.php ENDPATH**/ ?>