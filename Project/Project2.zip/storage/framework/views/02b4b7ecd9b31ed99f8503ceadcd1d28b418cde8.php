

<?php $__env->startSection('home-rb'); ?>
    <h1>Restaurant boss home strana</h1>

    <h2><?php echo e(auth()->guard()->user()->name); ?></h2>
    <br><br>

    <div class="row">
        <div class="col-md-6">
            <h3>Dostavljaci</h3>
            <table class="table">
                <thead>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Phone number</th>
                    <th>Action</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $deliverers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($d->name); ?></td>
                            <td><?php echo e($d->email); ?></td>
                            <td><?php echo e($d->address); ?></td>
                            <td><?php echo e($d->phone); ?></td>
                            <td>
                                <form action="<?php echo e(route('rest-boss.deleteStaff')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($d->id); ?>">
                                    <button type="submit" class="btn btn-danger">Remove</button>

                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <form action="<?php echo e(route('rest-boss.addDeliverer')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <td><input type="text" name="name" placeholder="name"></td>
                            <td><input type="text" name="email" placeholder="email"></td>
                            <td><input type="text" name="address" placeholder="address"></td>
                            <td><input type="text" name="phone" placeholder="phone"></td>
                            <td><input type="text" name="username" placeholder="username"></td>
                            <td><input type="password" name="password" placeholder="password"></td>

                            <td><button type="submit" class="btn btn-primary">Add</button></td>
                        </form>
                    </tr>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('rest-boss.showOrder')); ?>" type="button"
                                class="btn btn-outline-primary">Proverite dostave</a>
                        </td>
                    </tr>
                </tbody>
            </table>
            
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <h3>Konobari</h3>
            <table class="table">
                <thead>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Phone number</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $waiters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($d->name); ?></td>
                            <td><?php echo e($d->email); ?></td>
                            <td><?php echo e($d->address); ?></td>
                            <td><?php echo e($d->phone); ?></td>
                            <td>
                                <form action="<?php echo e(route('rest-boss.deleteStaff')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($d->id); ?>">
                                    <button type="submit" class="btn btn-danger">Remove</button>

                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <form action="<?php echo e(route('rest-boss.addWaiter')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <td><input type="text" name="name" placeholder="name"></td>
                            <td><input type="text" name="email" placeholder="email"></td>
                            <td><input type="text" name="address" placeholder="address"></td>
                            <td><input type="text" name="phone" placeholder="phone"></td>
                            <td><input type="text" name="username" placeholder="username"></td>
                            <td><input type="password" name="password" placeholder="password"></td>

                            <td><button type="submit" class="btn btn-primary">Add</button></td>
                        </form>
                    </tr>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('rest-boss.showOrders')); ?>" type="button"
                                class="btn btn-outline-primary">Proverite porudzbine</a>
                        </td>
                    </tr>
                </tbody>
            </table>
            
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <h3>Zaposleni zaduzeni za stanje</h3>
            <table class="table">
                <thead>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Phone number</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($d->name); ?></td>
                            <td><?php echo e($d->email); ?></td>
                            <td><?php echo e($d->address); ?></td>
                            <td><?php echo e($d->phone); ?></td>
                            <td>
                                <form action="<?php echo e(route('rest-boss.deleteStaff')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($d->id); ?>">
                                    <button type="submit" class="btn btn-danger">Remove</button>

                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <form action="<?php echo e(route('rest-boss.addState')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <td><input type="text" name="name" placeholder="name"></td>
                            <td><input type="text" name="email" placeholder="email"></td>
                            <td><input type="text" name="address" placeholder="address"></td>
                            <td><input type="text" name="phone" placeholder="phone"></td>
                            <td><input type="text" name="username" placeholder="username"></td>
                            <td><input type="password" name="password" placeholder="password"></td>

                            <td><button type="submit" class="btn btn-primary">Add</button></td>
                        </form>
                    </tr>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('rest-boss.statePage')); ?>" type="button"
                                class="btn btn-outline-primary">Proverite stanje</a>
                        </td>
                    </tr>
                </tbody>
            </table>
            
        </div>
        <div class="row">
            <div class="col-md-6">
                <h3>Sef restorana</h3>
                <table class="table">
                    <thead>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Phone number</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rest_boss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($d->name); ?></td>
                                <td><?php echo e($d->email); ?></td>
                                <td><?php echo e($d->address); ?></td>
                                <td><?php echo e($d->phone); ?></td>
                                <td>
                                    <form action="<?php echo e(route('rest-boss.deleteStaff')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($d->id); ?>">
                                        <button type="submit" class="btn btn-danger">Remove</button>

                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tr>
                        <form action="<?php echo e(route('rest-boss.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <td>
                                <input type="password" name="pwd" placeholder="Old password">
                            </td>
                            <td>
                                <input type="password" name="pwd_new" placeholder="New password">
                            </td>
                            <td>
                                <button type="submit" class="btn btn-success">Change password</button>
                            </td>
                        </form>
                    </tr>
                    <tr>
                        <td>
                            <form action="<?php echo e(route('rest-boss.logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-outline-primary">Logout</button>
                            </form>
                        </td>

                    </tr>
                </table>
                
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\resources\views/dashboard/rest-boss/home.blade.php ENDPATH**/ ?>