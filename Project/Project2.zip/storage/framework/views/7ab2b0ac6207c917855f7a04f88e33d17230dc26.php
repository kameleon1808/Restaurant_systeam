

<?php $__env->startSection('orders-w'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('orders', [])->html();
} elseif ($_instance->childHasBeenRendered('x7ZuBJR')) {
    $componentId = $_instance->getRenderedChildComponentId('x7ZuBJR');
    $componentTag = $_instance->getRenderedChildComponentTagName('x7ZuBJR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('x7ZuBJR');
} else {
    $response = \Livewire\Livewire::mount('orders', []);
    $html = $response->html();
    $_instance->logRenderedChild('x7ZuBJR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\Project\resources\views/dashboard/waiter/orders.blade.php ENDPATH**/ ?>