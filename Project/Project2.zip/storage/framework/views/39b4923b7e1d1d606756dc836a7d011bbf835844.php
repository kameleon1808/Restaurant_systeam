

<?php $__env->startSection('state-h'); ?>
    <h1>State home page</h1>

    <h2><?php echo e(auth()->guard()->user()->name); ?></h2>
    <br><br>

    <a type="button" href="<?php echo e(url('rest-boss/porucivana-jela')); ?>"
        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
        Najcesce porucivana jela
    </a>

    <a type="button" href="<?php echo e(url('rest-boss/prihodi')); ?>"
        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
        Prihodi
    </a>

    <a type="button" href="<?php echo e(url('rest-boss/mesecni-prihodi')); ?>"
        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
        Prihodi po mesecima
    </a>

    <a type="button" href="<?php echo e(url('rest-boss/godisnji-prihodi')); ?>"
        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
        Prihodi po godinama
    </a>
    <a type="button" href="<?php echo e(url('rest-boss/korisnici-prihodi')); ?>"
        class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
        Prihodi po korisnicima
    </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\resources\views/dashboard/rest-boss/state/state.blade.php ENDPATH**/ ?>