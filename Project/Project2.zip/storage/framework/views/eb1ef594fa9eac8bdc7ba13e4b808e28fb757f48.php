

<?php $__env->startSection('deliverer-h'); ?>
    <h1>Deliverer home page</h1>

    <h2><?php echo e(auth()->guard()->user()->name); ?></h2>
    <br><br>

    <table class="table">
        <thead>
            <th>id</th>
            <th>user_id</th>
            <th>boss_id</th>
            <th>city</th>
            <th>delievered
            <th>
            <th>location</th>
            <th>request</th>
            <th>Action</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($d->id); ?></td>
                    <td><?php echo e($d->user_id); ?></td>
                    <td><?php echo e($d->boss_id); ?></td>
                    <td><?php echo e($d->city); ?></td>
                    <td><?php echo e($d->delievered); ?></td>
                    <td>
                        <a
                            href="https://yandex.ru/maps/?whatshere[point]=<?php echo e($d->location); ?>&whatshere[zoom]=17"><?php echo e($d->location); ?></a>
                    </td>
                    <td><?php echo e($d->request); ?></td>
                    <td>
                        <?php if($d->boss_id == null): ?>
                            <input type="hidden" name="ord_id" value="<?php echo e($d->id); ?>">
                            <button type="submit">Porudzbina nije u procesu isporuke</button>
                        <?php elseif($d->boss_id != null): ?>
                            <?php if($d->request == 1): ?>
                                <input type="hidden" name="ord_id" value="<?php echo e($d->id); ?>">
                                <button type="submit">Porudzbina je u procesu isporuke</button>
                                <input type="text" name="loc" id="demo">
                            <?php else: ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php if($d->delivered != 1): ?>
                            <input type="hidden" name="ord_id" value="<?php echo e($d->id); ?>">
                            <button type="submit">Porudzbina i dalje nije dostavljena</button>
                        <?php elseif($d->delivered != 0): ?>
                            <button>Isporuceno</button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\resources\views/dashboard/rest-boss/deliverer.blade.php ENDPATH**/ ?>