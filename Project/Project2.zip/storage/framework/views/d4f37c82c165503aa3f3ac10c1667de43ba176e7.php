<div wire:poll>
    
    Current time: <?php echo e(now()); ?>


    <form action="<?php echo e(route('waiter.createOrder')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input name="article_name" type="text" class="form-control" placeholder="Naziv jela">
        <input name="prod_qty" type="text" class="form-control" placeholder="Kolicina">
        <input name="price" type="text" class="form-control" placeholder="Cena">
        <button type="submit" class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
            Kreiraj
        </button>
    </form>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">Kreirana u:</th>
                <th scope="col">Adresa za isporuku</th>
                <th scope="col">Porucilac</th>
                <th scope="col">Kontakt:</th>
                <th scope="col">Napomene:</th>
                <th scope="col">Racun:</th>
                <th scope="col">Jelo:</th>
                <th scope="col">Kolicina:</th>
                <th scope="col">Akcija:</th>
                <th scope="col">Akcija:</th>
                <th scope="col">Stanje:</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($order->order_date); ?></th>
                    <td><?php echo e($order->shipping_address); ?></td>
                    <td><?php echo e($order->name); ?></td>
                    <td><?php echo e($order->phone); ?></td>
                    <td><?php echo e($order->comments); ?></td>
                    <td><?php echo e($order->price); ?></td>
                    <td><?php echo e($order->article_name); ?></td>
                    <td><?php echo e($order->prod_qty); ?></td>
                    <td>
                        <?php if($order->accepted === 'PRIHVACENA'): ?>
                            <p></p>
                        <?php elseif($order->accepted === 'Prihvati'): ?>
                            <form action="<?php echo e(route('waiter.accept')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                                <input type="hidden" name="order_date" value="<?php echo e($order->order_date); ?>">
                                <button type="submit"
                                    class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
                                    <?php echo e($order->accepted); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($order->accepted === 'Prihvati'): ?>
                            <p></p>
                        <?php elseif($order->accepted === 'PRIHVACENA'): ?>
                            <form action="<?php echo e(route('waiter.refuse')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                                <input type="hidden" name="order_date" value="<?php echo e($order->order_date); ?>">
                                <button type="submit"
                                    class="nav-link btn btn-lg btn-secondary fw-bold border-white bg-dark">
                                    OTKAZI
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($order->canceled == 0): ?>
                            <input type="hidden" name="order_id" value="<?php echo e($order->canceled); ?>">
                            <button type="button" class="btn btn-outline-success" data-mdb-ripple-color="dark">
                                Na čekanju
                            </button>
                        <?php elseif($order->canceled == 1): ?>
                            <input type="hidden" name="order_id" value="<?php echo e($order->canceled); ?>">
                            <button type="button" class="btn btn-outline-danger" data-mdb-ripple-color="dark">
                                Otkazana
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\Project\resources\views/livewire/orders.blade.php ENDPATH**/ ?>