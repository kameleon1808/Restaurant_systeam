

<?php $__env->startSection('profile'); ?>
    <section class="item content">
        <div class="container toparea">
            <div id="edd_checkout_wrap" class="col-md-8 col-md-offset-2">

                <div id="edd_checkout_form_wrap" class="edd_clearfix">
                    <fieldset id="edd_checkout_user_info">
                        <form action="<?php echo e(route('user.updateInformation')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <legend>Personal Info</legend>
                            <p id="edd-email-wrap">
                                <label class="edd-label" for="edd-email">
                                    Email Address <span class="edd-required-indicator">*</span></label>
                                <input class="edd-input required" type="email" name="email" id="edd-email"
                                    value="<?php echo e(auth()->guard()->user()->email); ?>">
                            </p>
                            <p id="edd-first-name-wrap">
                                <label class="edd-label" for="edd-first">
                                    Full name <span class="edd-required-indicator">*</span>
                                </label>
                                <input class="edd-input required" type="text" name="name" id="edd-first"
                                    value="<?php echo e(auth()->guard()->user()->name); ?>" required="">
                            </p>
                            <p id="edd-last-name-wrap">
                                <label class="edd-label" for="edd-last">
                                    Address </label>
                                <input class="edd-input" type="text" name="address" id="edd-last"
                                    value="<?php echo e(auth()->guard()->user()->address); ?>">
                            </p>
                            <p id="edd-last-name-wrap">
                                <label class="edd-label" for="edd-last">
                                    Phone number </label>
                                <input class="edd-input" type="text" name="phone" id="edd-last"
                                    value="<?php echo e(auth()->guard()->user()->phone); ?>">
                            </p>

                            <input type="submit" class="edd-submit button" id="edd-purchase-button" name="edd-purchase"
                                value="Change information">
                        </form><br>

                        <form action="<?php echo e(route('user.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <label class="edd-label" for="edd-last">Your old password </label>
                            <input class="edd-input" type="password" name="pwd" placeholder="******">
                            <label class="edd-label" for="edd-last">Your new password </label>
                            <input class="edd-input" type="password" name="pwd_new" placeholder="******">





                            <input type="submit" class="edd-submit button" id="edd-purchase-button" name="edd-purchase"
                                value="Change password">
                        </form>
                    </fieldset>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\resources\views/dashboard/user/profile.blade.php ENDPATH**/ ?>