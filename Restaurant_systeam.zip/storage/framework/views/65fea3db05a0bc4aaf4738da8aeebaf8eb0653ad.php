

<?php $__env->startSection('home'); ?>
    <div class="container">
        <?php if(Auth::check()): ?>
            <?php if(auth()->guard()->user()->role == 1): ?>
                <h1>Dobrodosli <?php echo e(auth()->guard()->user()->name); ?></h1>
                <a href="<?php echo e('boss/home'); ?>" type="button" class="btn btn-primary">Pocetna strana</a><br>
            <?php elseif(auth()->guard()->user()->role == 2): ?>
                <h1>Dobrodosli <?php echo e(auth()->guard()->user()->name); ?></h1>
                <a href="<?php echo e('user/home'); ?>" type="button" class="btn btn-primary">Pocetna strana</a><br>
            <?php elseif(auth()->guard()->user()->role == 3): ?>
                <h1>Dobrodosli <?php echo e(auth()->guard()->user()->name); ?></h1>
                <a href="<?php echo e('waiter/home'); ?>" type="button" class="btn btn-primary">Pocetna strana</a><br>
            <?php elseif(auth()->guard()->user()->role == 4): ?>
                <h1>Dobrodosli <?php echo e(auth()->guard()->user()->name); ?></h1> 
                <a href="<?php echo e('state/home'); ?>" type="button" class="btn btn-primary">Pocetna stranaa</a><br>
            <?php elseif(auth()->guard()->user()->role == 5): ?>
                <h1>Dobrodosli <?php echo e(auth()->guard()->user()->name); ?></h1>
                <a href="<?php echo e('legal/home'); ?>" type="button" class="btn btn-primary">Pocetna strana</a><br>
            <?php elseif(auth()->guard()->user()->role == 6): ?>
                <h1>Dobrodosli <?php echo e(auth()->guard()->user()->name); ?></h1>
                <a href="<?php echo e('rest-boss/home'); ?>" type="button" class="btn btn-primary">Pocetna strana</a><br>
            <?php endif; ?>
        <?php else: ?>
            <h1>Izaberite vas restoran</h1>

            <div class="btn-group-vertical" role="group" aria-label="Vertical button group">
                <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e('address/' . $rest->name); ?>" type="button"
                        class="btn btn-primary"><?php echo e($rest->name); ?></a><br>
                    <input type="hidden" name="name" value="<?php echo e($rest->name); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\resources\views/dashboard/home.blade.php ENDPATH**/ ?>