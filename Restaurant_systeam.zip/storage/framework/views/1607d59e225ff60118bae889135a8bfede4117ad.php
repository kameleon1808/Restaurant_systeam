

<?php $__env->startSection('user-home'); ?>
    <!-- BUTTON =============================-->
    <div class="item content">
        <div class="container text-center">
            <a href="<?php echo e(url('user/shop')); ?>" class="homebrowseitems">Browse All Products
                <div class="homebrowseitemsicon">
                    <i class="fa fa-star fa-spin"></i>
                </div>
            </a>
        </div>
    </div>
    <!-- LATEST ITEMS =============================-->
    <section class="item content">
        <div class="container">
            <div class="underlined-title">
                <div class="editContent">
                    <h1 class="text-center latestitems">RANDOM ITEMS</h1>
                </div>
                <div class="wow-hr type_short">
                    <span class="wow-hr-h">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </span>
                </div>
            </div>
            <div class="row">

                <?php $__currentLoopData = $art; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- /.productbox -->
                    <div class="col-md-4">
                        <div class="productbox">
                            <div class="fadeshop">
                                <span class="maxproduct"><img src="<?php echo e(asset('images/product2-3.jpg')); ?>"
                                        alt=""></span>
                            </div>
                            <div class="product-details">
                                <a href="shop/<?php echo e($a->slug); ?>">
                                    <h1><?php echo e($a->name); ?></h1>
                                </a>
                                <span class="price">
                                    <span class="edd_price"><?php echo e($a->price); ?> RSD</span><br>
                                    <a href="shop/<?php echo e($a->slug); ?>" type="button" class="btn btn-info">Info</a>
                                </span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kamel\Documents\GitHub\Restaurant_systeam\resources\views/dashboard/user/home.blade.php ENDPATH**/ ?>