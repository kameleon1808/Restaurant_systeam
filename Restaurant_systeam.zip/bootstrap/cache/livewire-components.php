<?php return array (
  'delivery' => 'App\\Http\\Livewire\\Delivery',
  'orders' => 'App\\Http\\Livewire\\Orders',
  'requests' => 'App\\Http\\Livewire\\Requests',
);