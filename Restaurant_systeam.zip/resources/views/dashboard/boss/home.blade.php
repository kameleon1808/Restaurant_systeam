@extends('layouts.app')

@section('home-b')
    <livewire:delivery>
    @endsection
