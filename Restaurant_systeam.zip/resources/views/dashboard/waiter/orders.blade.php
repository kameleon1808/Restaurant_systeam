@extends('layouts.app')

@section('orders-w')
    <livewire:orders>
@endsection
